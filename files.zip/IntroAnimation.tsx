import { useEffect, useMemo, useState } from "react";

type Stage = "closed" | "opening" | "note" | "done";

const LOVE_NOTE = `To my Sanaya,

Every day with you feels like a gift I get to unwrap all over again. Your smile lights up every room, your laugh is my favorite sound, and your heart is the kindest I've ever known. Thank you for loving me so fully and for making our story the best one I know. Here's to us, and to forever. I love you more than words can hold.

Happy anniversary, my love.`;

const STORAGE_KEY = "sanaya-intro-seen";

function ConfettiBurst() {
  const pieces = useMemo(() => {
    const emojis = ["♥", "♡", "✦"];
    return Array.from({ length: 22 }).map((_, i) => {
      const angle = Math.random() * Math.PI * 2;
      const distance = 90 + Math.random() * 140;
      const tx = Math.round(Math.cos(angle) * distance);
      const ty = Math.round(Math.sin(angle) * distance - 60);
      const rot = Math.round(Math.random() * 360);
      const delay = Math.round(Math.random() * 150);
      const size = 12 + Math.round(Math.random() * 10);
      const color = i % 3 === 0 ? "#c5a059" : "#e7a0a8";
      return { id: i, tx, ty, rot, delay, size, color, emoji: emojis[i % emojis.length] };
    });
  }, []);

  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 flex items-center justify-center">
      {pieces.map((p) => (
        <span
          key={p.id}
          style={{
            position: "absolute",
            fontSize: p.size,
            color: p.color,
            animation: `intro-confetti-burst 1.1s ease-out ${p.delay}ms forwards`,
            // @ts-expect-error custom properties consumed by the keyframe
            "--tx": `${p.tx}px`,
            "--ty": `${p.ty}px`,
            "--rot": `${p.rot}deg`,
          }}
        >
          {p.emoji}
        </span>
      ))}
    </div>
  );
}

export function IntroAnimation() {
  const [stage, setStage] = useState<Stage>(() => {
    if (typeof window === "undefined") return "closed";
    return window.sessionStorage.getItem(STORAGE_KEY) ? "done" : "closed";
  });

  useEffect(() => {
    if (stage === "done") {
      document.body.style.overflow = "";
      return;
    }
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, [stage]);

  const handleOpen = () => {
    if (stage !== "closed") return;
    setStage("opening");
    window.setTimeout(() => setStage("note"), 750);
  };

  const finish = () => {
    window.sessionStorage.setItem(STORAGE_KEY, "1");
    setStage("done");
  };

  if (stage === "done") return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center overflow-hidden bg-gradient-to-b from-blush via-cream to-blush">
      <button
        onClick={finish}
        className="absolute right-6 top-6 z-20 font-heading text-[11px] uppercase tracking-[0.25em] text-wine/50 transition-colors hover:text-wine"
      >
        Skip intro
      </button>

      {/* ambient glow, consistent with the homepage hero */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div
          className="absolute -left-24 -top-24 size-96 rounded-full"
          style={{ background: "radial-gradient(circle, rgba(231,160,168,.5), transparent 70%)" }}
        />
        <div
          className="absolute -right-24 bottom-0 size-96 rounded-full"
          style={{ background: "radial-gradient(circle, rgba(197,160,89,.3), transparent 70%)" }}
        />
      </div>

      {(stage === "closed" || stage === "opening") && (
        <div className="relative z-10 flex flex-col items-center">
          <button
            onClick={handleOpen}
            aria-label="Open your surprise"
            className={`relative ${stage === "closed" ? "intro-box-bounce" : ""}`}
          >
            <div className="relative h-32 w-40 sm:h-36 sm:w-48">
              {/* box base */}
              <div className="absolute inset-x-0 bottom-0 h-24 rounded-b-xl bg-wine shadow-xl sm:h-28" />
              {/* lid */}
              <div
                className={`absolute inset-x-0 top-0 h-14 rounded-t-xl bg-wine shadow-lg sm:h-16 ${
                  stage === "opening" ? "intro-lid-pop" : ""
                }`}
              />
              {/* ribbon */}
              <div className="absolute inset-y-0 left-1/2 w-4 -translate-x-1/2 bg-gold sm:w-5" />
              <div className="absolute inset-x-0 top-1/2 h-4 -translate-y-1/2 bg-gold sm:h-5" />
              {/* bow */}
              <div
                className={`absolute -top-7 left-1/2 -translate-x-1/2 text-3xl ${
                  stage === "opening" ? "intro-ribbon-untie" : ""
                }`}
              >
                🎀
              </div>
            </div>
            {stage === "opening" && <ConfettiBurst />}
          </button>

          <p className="mt-8 font-heading text-xs uppercase tracking-[0.3em] text-wine/60">
            {stage === "closed" ? "tap to open your surprise" : "opening…"}
          </p>
        </div>
      )}

      {stage === "note" && (
        <div className="intro-note-unfold relative z-10 mx-6 max-w-md rounded-2xl border border-gold/30 bg-cream px-8 py-10 text-center shadow-2xl">
          <p className="font-script text-2xl text-wine">a little note for you</p>
          <p className="mt-5 whitespace-pre-line font-body text-lg leading-relaxed text-ink/80">
            {LOVE_NOTE}
          </p>
          <button
            onClick={finish}
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-wine px-7 py-3 font-heading text-sm tracking-wide text-cream transition-transform hover:scale-105"
          >
            Continue to our story →
          </button>
        </div>
      )}
    </div>
  );
}
